
from .navec import Navec  # noqa
