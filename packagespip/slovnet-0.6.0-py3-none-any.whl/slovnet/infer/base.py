
class Infer:
    def __init__(self, model, encoder, decoder):
        self.model = model
        self.encoder = encoder
        self.decoder = decoder
