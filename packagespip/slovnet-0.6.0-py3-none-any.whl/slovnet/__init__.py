
from .api import NER, Morph, Syntax  # noqa
