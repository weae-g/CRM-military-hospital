

from .constructors import (
    is_relation,
    Main,
    Relation,
    AndRelation,
    OrRelation,
    NotRelation
)
from .bank import *


main = Main
